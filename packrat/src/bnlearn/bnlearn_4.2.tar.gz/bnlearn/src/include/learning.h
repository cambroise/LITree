
/* shared between hill climbing and tabu search. */
void bestop_update(SEXP bestop, char *op, const char *from, const char *to);

