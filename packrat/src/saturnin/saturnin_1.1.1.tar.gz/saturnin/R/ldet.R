ldet <-
function(M){determinant(M,logarithm=TRUE)$modulus[1]}
